#include <stdio.h>
int main()
{
	//�Է�, �Է¾��, �������
	int n1, n2, n3, n4, n5;
	float f; double d;

	printf("2147483647 �Է� : ");
	scanf("%d", &n1); 
	printf("%d \n", n1);

	printf("2147483647 �Է� : ");
	scanf("%1d%2d%3d%d", &n1, &n2, &n3, &n4);
	printf("%d %d %d %d\n", n1, n2, n3, n4);
	printf("%2d %04d %2d %5d\n", n1, n2, n3, n4);

	printf("123-12345 �Է� : ");
	scanf("%d-%d", &n1, &n2); 
	printf("%d %d\n", n1, n2);

}
